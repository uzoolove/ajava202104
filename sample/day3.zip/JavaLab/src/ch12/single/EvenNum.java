package ch12.single;

public class EvenNum {
	// 1~10 까지의 짝수 출력
	public void printEven(){
		
	}
}

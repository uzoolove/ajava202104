package ch12.single;

public class OddNum {
	// 1~10 까지의 홀수 출력
	public void printOdd(){
		
	}
}

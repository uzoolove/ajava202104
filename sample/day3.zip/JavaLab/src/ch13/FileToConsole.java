package ch13;


/**
 * 파일(output.txt) -> 표준출력장치(콘솔)
 * @author student
 *
 */
public class FileToConsole {
	public static void main(String[] args) {
		
	}
}

























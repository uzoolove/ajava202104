package ch13;

/**
 * 표준입력장치(키보드)에서 읽은 내용을 표준출력장치(콘솔)에 출력한다.
 * @author student
 *
 */
public class KeyboardToConsole {
	public static void main(String[] args) {	
		
	}
}

























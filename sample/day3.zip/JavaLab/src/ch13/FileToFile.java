package ch13;


/**
 * 파일(output.txt) -> 파일(output2.txt)
 * @author student
 *
 */
public class FileToFile {
	public static void main(String[] args) {
		
	}
}

























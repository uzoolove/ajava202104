package echo;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;

public class EchoServerThread extends Thread{
	private Socket s;
	private BufferedReader in;
	private PrintWriter out;
	
	public void run(){
		try{
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}





















